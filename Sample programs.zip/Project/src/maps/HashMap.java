package maps;



public class HashMap {

	public static void main(String[] args) {
	
	//Map is a interface what ever methods present in MAp are being implement in Hashmap class
	// duplicate keys are not allowed but duplicate values are allowed
	// if you try to add duplicate key with other value it will not error instead it will update with new value
	// entry = key+value 
	// Internal under lying data structure of Hash Map is Hash Table
	//Inseration order is not preserved becoz Hashing doesnot presever  Inseration order
	// null key allowed only once becoz keys are unique but null values are multiple 
	//	Searching is fast 
	
		HashMap map = new HashMap();
		
	/*	
	
		m.put(key,value);
		m.putAll(Map m1) //multiple key value pair we can add
		m.get(key);
		m.remove(key);
		m.containskey(key);
		m.containsvalue(value);
		m.isEmpty();
		m.size();
		m.clear();
		
		// the below methods will work on key and value pairs
		
		m.keyset();  it will return all keys in Hashmap and we can store in Set(return type) becoz no duplicates
		m.values(); it will return all the values in Hashmap and we can store in Collection
				
		m.entryset(); //it will return all the entries from Hashmap we can store in Set
		
		//Entry Interface is subset of HashMap and below are Some methods
		
	//e.getKey();
	//e.getvalue();
	//e.setvalue();
	 
*/	
		
		
		
		
		
		
		
				
		
		
		
		
		
		
		

	}

}
