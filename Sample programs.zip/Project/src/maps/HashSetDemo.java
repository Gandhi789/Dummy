package maps;
import java.util.HashSet;
import java.util.Iterator;
public class HashSetDemo {

	public static void main(String[] args) {

//duplicates not allowed 
		
//Inseration order not preserved 
				
//Hash code is concept by which elements will be inserted ,becoz of this searching a elements is very fast 
				
// No index concept 
				
//Heterogines data and nulls are allowed 
		
//load factor and Fill ratio os 0.75 
				
//Ways to Create a Hash Set 
										

		
HashSet hs =new HashSet(); //by default it will allocate 16 locations initial size 
hs.add(100);
hs.add("welcome");
hs.add(16.4);
hs.add('A');
hs.add(true);
hs.add(null);
System.out.println(hs);

//remove
hs.remove(16.4);
System.out.println(hs);

//contains()
hs.contains("Welcome");
System.out.println(hs.contains("Welcome"));

//isEmpty()
hs.isEmpty();
System.out.println(hs.isEmpty());

System.out.println("********************************");

//Reading from HashSet only for each loop and iterator

//Reading elements from hash set using for each loop

for(Object k:hs)
{
	System.out.println(k);
}

System.out.println("*******************************");

Iterator it =hs.iterator();

while(it.hasNext())
{
	System.out.println(it.next());
}


	}

}
