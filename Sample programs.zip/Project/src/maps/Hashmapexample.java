package maps;
import java.util.HashMap ;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Hashmapexample {

	public static void main(String[] args) {
		HashMap<Integer, String> m = new HashMap<Integer, String>();
		//HashMap m=new HashMap();
		m.put(101, "john");
		m.put(102, "david");
		m.put(103, "Gandhi");
		m.put(104, "Vamsi");
		m.put(104, "Veera");
		m.put(105, "Veera");
		System.out.println(m);
		System.out.println(m.get(105));
		m.remove(103); 
		System.out.println(m);
		System.out.println(m.containsKey(103));
		m.containsValue("david");
		System.out.println(m.containsValue("david")); //true
		m.isEmpty();
		System.out.println(m.isEmpty()); //false
		
		//keySet and values 
		m.keySet();
		

		
		m.entrySet();
		
		
		
		System.out.println("********************************");
		System.out.println(m.keySet()); //returns all keys as SET
		for(int k:m.keySet())
		{
			System.out.println(k);
		}
		System.out.println("********************************");
		System.out.println(m.values());// return all values ad Collection 
		for(Object k:m.values())
		{
			System.out.println(k);
		}
		//key along with value
		
		for(Object k:m.keySet())
		{
			System.out.println(k+"  "+m.get(k));
		}
		
		/// Entry Methods
		
		System.out.println("********************************");
		
		System.out.println(m.entrySet());//Returns all the enteries as Set [101=john,102=david,102="gandhi"..]

	
		
		
		for(Map.Entry entry :m.entrySet()) // first entry 101 john
		{
			System.out.println(entry.getKey()+" "+entry.getValue());
		}
		
		//iterator()
		System.out.println("$$$$$$$$$$$$$$$$$$$$$$$");
		Set s=m.entrySet();
		
		Iterator it=s.iterator();
		
		while(it.hasNext())
		{
			System.out.println(it.next());
			
		}
		
		
		
	}
}
