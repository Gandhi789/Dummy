package thisKeyword;

//Java code for using 'this' keyword to
//refer current class instance variables

public class TestTHIS {
	
	
	int a ;
	int b;
	
	TestTHIS(int a ,int b)
	{
		this.a=a;
	    this.b=b;
	}
void display()
{
	System.out.println("a="+a);
	System.out.println("b="+b);
}
	public static void main(String[] args) {
		TestTHIS k=new TestTHIS(10,20);
		k.display();
		

	}

}
