package thisKeyword;

public class TestTHIS1 {
	
	int a;
	int b;
	
	TestTHIS1()
	{
	this(10,20);
	System.out.println("Inside  default constructor \n");
	}
	
	TestTHIS1(int a ,int b)
	{
		this.a=a;
		this.b=b;
		System.out.println("Inside  paramaterized constructor \n");
	}
	
	void display()
	{
		System.out.println("a=:" +a);
	}

	public static void main(String[] args) {
		
		TestTHIS1 k= new TestTHIS1();
		
		
	

}
}
