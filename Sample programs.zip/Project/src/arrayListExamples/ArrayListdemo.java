package arrayListExamples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class ArrayListdemo {

	public static void main(String[] args) {
		
		//Duplicate data 
		//Hetrogenous data 
		
	     //Declare ArrayList 

	//List a1=new ArrayList();
	ArrayList a1=new ArrayList();
	a1.add(100);
	a1.add("welcome");
	a1.add(15.5);
	a1.add('A');
    a1.add(true);
System.out.println(a1); // [100, welcome, 15.5, A, true]
System.out.println(a1.size());
System.out.println(a1.size());
	//a1.remove(1);
a1.remove("welcome");// removing via index or direct value is possibile
System.out.println(a1);
	//insert a new element //add(index,object)
a1.add(2,"python");
System.out.println(a1);
	
	//retrive specfic element
System.out.println(a1.get(2));

//replace element use this set(index,object)
a1.set(2,"C#");
System.out.println(a1);

//searching use contains() true or false

a1.contains("C#");
System.out.println(a1.contains("C#"));

a1.isEmpty();
System.out.println(a1.isEmpty());


//Using Iterator we are reading the elements ,similiary using for ,for each ,lambda
Iterator it=a1.iterator();

while(it.hasNext())
{
	
	System.out.println(it.next());
}

///////////////////////////////

ArrayList a2=new ArrayList();
a2.add("X");
a2.add("Y");
a2.add("Z");
a2.add("A");
a2.add("B");

System.out.println(a2);

ArrayList a3=new ArrayList();

a3.addAll(a2);

System.out.println(a3);

a3.removeAll(a2);
System.out.println(a3);

//Sort--------------Collections.sort()

System.out.println("before sorting" +a2);
Collections.sort(a2);
System.out.println("After sorting" +a2);
System.out.println("***********");


Collections.sort(a2, Collections.reverseOrder()); //reversing
System.out.println("elements in after sorting" +a2);

//Shuffling
Collections.shuffle(a2);
System.out.println(a2);


      //Converting Array into ArrayList

String arr[]={"Dog","Cat","Elephant"};


for(String k:arr)
{
	System.out.println(k);
}
	//Converted Array into ArrayList
ArrayList a4=new ArrayList(Arrays.asList(arr));
System.out.println(a4);
		
		
		
		
		
		
		
		
		
		
	}

}
