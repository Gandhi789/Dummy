package arrayListExamples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ArrayToArrayListExample {

	public static void main(String[] args) {
		Integer[] array = new Integer[]{1,2,3,4};
		
		List<Integer> lst =Arrays.asList(array);
		
		//lst.add(6);  will throw java.lang.UnsupportedOperationException
		System.out.println("orginial list: " +lst);
		lst.set(0, 6);
		System.out.println("updated list: " +lst);
		
		System.out.println("updated array: " +Arrays.toString(array));
		
//////////// other way
		
		ArrayList<Integer> alist =new ArrayList<Integer>(Arrays.asList(array));
		
		
		// using addALL method
		ArrayList<Integer> alist1 =new ArrayList<Integer>();
		Collections.addAll(alist1, array);
		System.out.println(alist1);
	}

}
