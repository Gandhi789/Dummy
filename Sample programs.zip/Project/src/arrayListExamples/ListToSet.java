package arrayListExamples;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;




public class ListToSet {

	public static void main(String[] args) {
		
		List<String> listcolors = new ArrayList<String>();
		listcolors.add("Red");
		listcolors.add("Blue");
		listcolors.add("Yellow");
		listcolors.add("Green");
		listcolors.add("White");
		listcolors.add("White");
		
		System.out.println(listcolors);
		// Using HashSet Constructor
		
		
		
		Set<String> s =new HashSet<String>(listcolors);
		System.out.println(s);
		
	
		System.out.println("*****************");
		// Using the addAll method of HashSet 
		
		Set<String> s1 =new HashSet<String>();
		s1.addAll(listcolors);
		System.out.println(s1);
		
		
		// Using Apache Commons library
		
		Set<String> s3 =new HashSet<String>();
	//	CollectionUtils.addAll(s3,listcolors);
		System.out.println(s3);
		
		// Using Stream (Java 8)
		
		Set<String> s4 =listcolors.stream().collect(Collectors.toSet());
		System.out.println(s4);
		
	}

}
