package arrayListExamples;

import java.util.ArrayList;
import java.util.Arrays;

public class getelementsfromArrayList {

	public static void main(String[] args) {

		
		// duplicate  are allowed
		// inseration order preserved

	ArrayList<String> alist = new ArrayList<>();
	alist.add("One");
	alist.add("Two");
	alist.add("Three");
	System.out.println(alist.size());
	System.out.println("The first element is " + alist.get(0));
	System.out.println("The last elements is" +alist.get(alist.size()-1));
		
	//using advance for loop 
	System.out.println("*******************************************");
	for(String k:alist)
		
	{
		System.out.println(k);
	}
	
	//using normal for loop
	System.out.println("***********************************");
	for(int i=0;i<alist.size();i++)
	{
		System.out.println(alist.get(i));
	}
	
	//Using Array class--Conver Arraylist into Array and use toString method
	System.out.println(Arrays.toString(alist.toArray()));
	
	// if u want to remove the square bracks use below
	System.out.println(Arrays.toString(alist.toArray()).replaceAll("[\\[\\]]", ""));
		
	System.out.println("*********************");
	
	//Using Jave 8 stream
	alist.stream().forEach(System.out::println);
	
	
	
	
	/* Make sure to specify type when you declare an ArrayList .IF ArrayList is declared 
	without type ,the get method returns an object of the object class and you have to cast it 
	down to appropriate type

	   
	 */
//	ArrayList al=new ArrayList();
//	al.add("Gandhi");
	
//	System.out.println(((String)al.get(0)).toLowerCase());

	}

}
