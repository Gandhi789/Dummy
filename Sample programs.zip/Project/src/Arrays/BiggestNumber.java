package Arrays;

public class BiggestNumber {

	public static void main(String[] args) {

//int [] a=new int[5];

//char[] c={'r','a','j'};
		
		int [] a={20,15,100,45,70 };
		
		int big=0;
		for(int i=0;i<=a.length-1;i++)
		{
			if(a[i]>big)
			{
				big=a[i];
			}
		}

		System.out.println(big);
		
		

	}

}
