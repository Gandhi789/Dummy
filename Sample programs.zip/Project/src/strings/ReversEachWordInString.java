package strings;

public class ReversEachWordInString {

	public static void main(String[] args) {
		
		
		String input="java is very easy";
	
		
		
		String[] str=input.split("\\s");
		
		for(String k:str)
		{
			String rev="";
			for(int i=k.length()-1;i>=0;i-- )
			{
				rev=rev+k.charAt(i);
			}
			rev=rev+" ";
			System.out.print(rev);
		}
		
	}
}
		
