package strings;

public class PigLatin {
	

	public static void main(String[] args) {

     String str="child";
     String value="";
     
     char[] ch=str.toCharArray();
     
     int i;
     for(  i=0;i<str.length();i++)
     {
    	 
    	// System.out.println(ch[i]);
    	 
    	 if(ch[i]=='a' || ch[i]=='e' || ch[i]=='i' ||ch[i]=='o' ||ch[i]=='u' )
    	 {
    		 break;
    	 }
    	 
    	 
    	
    	 
     }
     
     
     String pig= str.substring(i);
		
     value=pig +str.substring(0,i-0)+"ay";
System.out.println(value);
	}

}
