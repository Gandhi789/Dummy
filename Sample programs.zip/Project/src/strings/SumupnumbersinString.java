package strings;

public class SumupnumbersinString {

	public static void main(String[] args) {

		String s="aa33b2cgg3dasdff4";
		
		char[] c=s.toCharArray();
		int sum=0;
		
		for(char k:c)
		{
			if(Character.isDigit(k))
			{
				sum=sum+k;
				
				
			}
		}
		
		
		

	}

}
