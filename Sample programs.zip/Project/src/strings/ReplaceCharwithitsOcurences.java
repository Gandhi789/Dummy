package strings;

public class ReplaceCharwithitsOcurences {

	public static void main(String[] args) {
		String str="opentext";
		//expectedoutput=open1ex2
		char chartoreplace='t';
		
		
		if(str.indexOf(chartoreplace)==-1)	
		{
			System.out.println("it is not present in string");
		}
		else
		{
			char[] ch=str.toCharArray();
			
			int count=1;
			for(int i=0;i<ch.length;i++)
			{
				
				if(ch[i]==chartoreplace)
				{
				
					//ch[i]=count;
				ch[i]=String.valueOf(count).charAt(0);
				count++;	
				}
				
			}
			System.out.println(ch);	
			
		}
		
		//Approach using second logic  


	}

}
