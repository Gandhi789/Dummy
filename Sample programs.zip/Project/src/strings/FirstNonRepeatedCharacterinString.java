package strings;

public class FirstNonRepeatedCharacterinString {

	public static void main(String[] args) {

//indexof()=== returns the position of the first occurrence of a given character in a string
//lastIndexOf()== returns the position of the last occurrence of a given character in a string.		

		String str="stress";
		
		char[] ch=str.toCharArray();
		
		for(char k:ch)
		{
			
			if(str.indexOf(k)==str.lastIndexOf(k))
			{
				System.out.println(k);
				break;
			}
			
		}
		
		
		
	}

}
