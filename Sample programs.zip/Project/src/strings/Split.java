package strings;

import java.util.List;
import java.util.StringTokenizer;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class Split {

	public static void main(String[] args) {

		/* different ways to split a string
	    1) String class split method
		2) Pattern.compile(regex).splitAsStream(String)
		3) String tokenizer
		4) StringUtils.split(String,�exp�)
		5) Splitter.on(�-�).split(s);
		*/
				
		 String s="091-0123456789";
		
		 String str[]= s.split("-");
		   
		 for(String k:str)
		  {
			  System.out.println(k);
		  }
		 
		 
		 System.out.println("**************************");
		 List<String> stri=Pattern.compile("-").splitAsStream(s).collect(Collectors.toList());
		   for(String k:stri)
		   {
			   System.out.println(k);
		   }
		   
		   
		   System.out.println("**************************");
		   
		   StringTokenizer st=new StringTokenizer(s,"-");
		   
		   
		  
		   
		   
		/*   
		 public static void printString(String str[],String approch)
		   {
			  for(String k:str)
			  {
				  System.out.println(k);
			  }
		   }
		
		*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
