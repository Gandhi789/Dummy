package strings;

public class RemoveWhitespace {

	
	public static void main(String[] args) {
		//trim() method is used to remove white spaces before and after the string only,i cannot use for all spaces

		//by using unocode //s means single space between the character
		String str = " j a  va s ta r ";

		String trimmedstr = str.replaceAll("\\s", "");

		System.out.println(trimmedstr);

	}

}
