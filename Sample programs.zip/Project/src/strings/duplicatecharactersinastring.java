package strings;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class duplicatecharactersinastring {

	public static void main(String[] args) {

        //Input:Programming
		//output: poraming
		
		//Four Approaches are there 
		//1.using java 8
		//2.Using  indexof(..)
		//3.Using Character Array
		//4.Using Set interface
		
		String str="Programming";
		StringBuilder sb=new StringBuilder();
		str.chars().distinct().forEach(c->sb.append((char)c));
		System.out.println(sb); 
		
		//Approach-2
		StringBuilder sb2=new StringBuilder();
		for(int i=0;i<str.length();i++)
		{
			char ch=str.charAt(i);
			int index=str.indexOf(ch,i+1);
			if(index==-1)
			{
				sb2.append(ch);
			}
			
		}
		
System.out.println(sb2);

//Approach --------using char array 

char[] ch3=str.toCharArray();
StringBuilder sb3=new StringBuilder();

for(int i=0;i<ch3.length;i++)
{
	boolean repeated=false;
	for(int j=i+1;j<ch3.length;j++)
	{
	if(ch3[i]==ch3[j])
		{
			repeated=true;
			break;
		}
	}
	if(!repeated)
	{
		sb3.append(ch3[i]);	
	}
	
	
	}
System.out.println(sb3);
	
//Approach-4 using Set interface

StringBuilder sb4=new StringBuilder();

Set<Character> set=new LinkedHashSet<Character>();

for(int i=0;i<str.length();i++)
{
	set.add(str.charAt(i));
}

for(Character c:set)
{
	sb4.append(c);
}
System.out.println(sb4);
	}

}
