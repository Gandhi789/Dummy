package strings;

public class specialcharactersremoving {

	public static void main(String[] args) {
		
		
		//input:$ja!va@&%ast#a%r
		
		//output "javastar
		
		// Approach -1---Using ReplaceAll method
		
		String str="$ja!va@&%ast#a%r";
		str.replaceAll("[^a-zA-Z0-9]", "");
		
		String plain=str.replaceAll("[^a-zA-Z0-9]", "");
		System.out.println(plain);
		

	}

}
