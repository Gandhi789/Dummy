package strings;

import java.util.Arrays;

public class SortinginAlphabeticOrder {

	public static void main(String[] args) {
		
	// we can sort any string in 2 ways 
		
	// 1.with out using sort method 
	// 2.with using sort method 
		
		String str="java";
		
		char[] ch=str.toCharArray();
		char temp ;
		for(int i=0;i<ch.length;i++)
		{
		
			for(int j=i+1;j<ch.length;j++)
			{
				if(ch[i]>ch[j])
				{
					temp=ch[i];
					ch[i]=ch[j];
					ch[j]=temp;
				}
			}
			
			
		}
			
			System.out.println(ch);	
			
		//Approach 2:with out using sort 	
			
			char[] chararray=str.toCharArray();
			Arrays.sort(chararray);
			System.out.println(chararray);
			
		}
		

	}

	


