package strings;

public class SubstringsofaString {

	public static void main(String[] args) {
		
		String a="gandhis";
		
		String b="tataji";
		
		System.out.println(a);
		
		System.out.println(b);
		
		a=a+b; //gandhitataji
	
		b=a.substring(0,a.length()-b.length());
		a=a.substring(b.length());
		System.out.println(b);
		System.out.println(a);
		
	
		
		
		
	/*	String str="gandhi";
		
		for(int i=0;i<str.length();i++)
		{
			for(int j=i+1;j<str.length();j++)
			
			{
				
				System.out.println(str.substring(i, j));
				
			}
		}

	}*/

}
}
