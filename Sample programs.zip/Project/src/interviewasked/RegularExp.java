package interviewasked;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExp {

	public static void main(String[] args) {

  String str="gandhi2mayur3";
  
  Pattern p= Pattern.compile("[a-z]+");
  Matcher m=p.matcher("gandhi2mayur3");
  
  Pattern p1=Pattern.compile("[0-9]+");
  Matcher m1=p1.matcher("gandhi2mayur3");
  
  while(m.find()&& m1.find())
  {
	
	  
     String k= m1.group();
	 int k1=Integer.parseInt(k);
	 
	for(int i=0;i<k1;i++)
	{
		 System.out.print(m.group());
	}
	 
	  
	 
	  
  }
  
		
	}

}
