package interviewasked;

public class Reverese {

	public static void main(String[] args) {

String Str="Gandhi today java preparation"; //

String[] result=Str.split("\\s");
String rev="";


for(int i=result.length-1;i>=0;i--)
{
	//System.out.print(result[i]);
	
	rev=rev+result[i]+" ";
	
	
}
System.out.println(rev);






		
		
	}

}
