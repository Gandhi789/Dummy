package interviewasked;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Korr {

	public static void main(String[] args) {

		
		    {
		        int sum=0;
		        String s="Ab12cd4f";
		        Pattern p=Pattern.compile("[a-z]+");
		        Pattern numbers=Pattern.compile("[0-9]+");
		        Matcher m=p.matcher(s);
		        Matcher num=numbers.matcher(s);
		        while(num.find()&&m.find()){
		          // System.out.println("o/p of matched given pattern chars:"+m.group());
		           // System.out.println("o/p of matched given pattern int:"+num.group());
		            Integer x = Integer.parseInt(num.group());
		            //System.out.println("Number of times:"+x);
		            for(int i=1;i<=x;i++){
		                System.out.print(m.group());
		            }
		        }

		    }
		}

	}


