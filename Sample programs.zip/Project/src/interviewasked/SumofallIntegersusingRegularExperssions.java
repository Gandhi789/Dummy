package interviewasked;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SumofallIntegersusingRegularExperssions {

	public static void main(String[] args) {

int sum=0;
		String str="1abc22er2rtt";
		
		String regex = "([0-9]+)";
		
		//String regex=�\\d+�;
		//Creating a Pattern Object 
		 Pattern p = Pattern.compile(regex);
		 
		  //Creating a Matcher object
	      Matcher m = p.matcher(str);
	      
	      while(m.find()) {
	          //System.out.print(m.group()+" ");
	         // System.out.println(m.group());//this is string in new lines 
	          System.out.println("************************");
	          int n = Integer.parseInt(m.group());
	          System.out.println(n);
	          sum=sum+n;
	       }
	      System.out.println(sum);
	      

	}

}
