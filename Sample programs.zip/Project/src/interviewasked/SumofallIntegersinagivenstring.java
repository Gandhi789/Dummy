package interviewasked;

public class SumofallIntegersinagivenstring {

	public static void main(String[] args) {
		
		String temp="0";
		int sum=0;
		String str="1abc22er2rtt";
		
		/*for(int i=0;i<str.length();i++)
		{
			    char ch=str.charAt(i);
			    System.out.println(ch);
		}
		*/
		
		char[] ch=str.toCharArray();
		for(char k:ch)
		{

			if(Character.isDigit(k))
			{
				temp=temp+k;
			}
			else
			{
				sum=sum+Integer.parseInt(temp);
				temp="0";
			}
			
		
			
			
			
		}
		System.out.println(sum);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
