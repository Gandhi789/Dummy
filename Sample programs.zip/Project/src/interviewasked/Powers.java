package interviewasked;

public class Powers {

	public static void main(String[] args) {

double m=2;
double n =3;

    double k=Math.pow(m,n);
    
    double l=Math.sqrt(3);
    
    double o=Math.cbrt(m);

    System.out.println(k);
		
    System.out.println(l);
    
    System.out.println(o);
	}

}
