package patterns;

public class IncreaseStarTriangle {

	public static void main(String[] args) {
		/*	for(int j=0;j<n;j++)
		{
			System.out.print("*"); //01234
		}
		*/
		
int n=4;

		for(int i=1;i<=n;i++)
		{
		for(int j=1;j<=n;j++)
		{
			System.out.print("* ");  //12345
		}
		System.out.println();
		}
	
		//Increasing Traingle
		System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
		
		
		for(int i=1;i<=n;i++)
		{
		for(int j=1;j<=i;j++)
		{
			System.out.print("* ");  //12345
		}
		System.out.println();
		}
		
		
		
		

	}

}
