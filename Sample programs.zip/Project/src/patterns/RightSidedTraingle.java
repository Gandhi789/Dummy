package patterns;

public class RightSidedTraingle {

	public static void main(String[] args) {

//Decreasing Space   
		
//Increasing Star
		
		
		int n=5;
		
		for(int i=1;i<=n;i++)
		{
			
		for(int j=i;j<=n;j++)
		{
	    System.out.print(" ");
					
		}
		for(int j=1;j<=i;j++)
		{
			System.out.print("*");
		}
		
			
			System.out.println();
		}
		
		
		System.out.println("##########################################");
		System.out.println("##########################################");
		
		//Increasing Space and decreasing star
		
		/*for(int i=1;i<=n;i++)
		{
			
			for(int j=1;j<=i;j++)
			{
				System.out.print(" ");
			}
			
			for(int j=i;j<=n;j++)
			{
				System.out.print("*");
			}
			
			
			System.out.println();
		}
		*/
		
		
		for(int i=1;i<=n;i++)
		{
			
			for(int j=1;j<=i;j++)
			{
				System.out.print(" ");
			}
			for(int j=i;j<=n;j++)
			{
				System.out.print("*");
			}
			
			System.out.println();
		}
		
		
		
		
		
		
		
		
		
		

	}

}
