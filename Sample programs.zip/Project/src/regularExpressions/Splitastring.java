package regularExpressions;

import java.util.regex.Pattern;

public class Splitastring {

	public static void main(String[] args) {

		String str = "I have a cat. I play cricket with bat i hate mats, now break it";
	            
		Pattern p=Pattern.compile("(cat|bat|it)");
		String[] parts=p.split(str);
		for(String k:parts)
		{
			System.out.println(k);
		}
		
		
		
		
	}

}
