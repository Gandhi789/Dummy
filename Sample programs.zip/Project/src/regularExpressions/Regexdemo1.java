package regularExpressions;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regexdemo1 {

	public static void main(String[] args) {

Pattern p=Pattern.compile("[a-z]+");
Matcher m=p.matcher("ay7b@zrtt#9");
while(m.find())
{
	System.out.println(m.start()+"..."+m.group());
}


//x=[abc]---


		
		

	}

}
