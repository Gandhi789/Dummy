package generalPrograms;

public class StringMethods {

	public static void main(String[] args) {


		
		String str="The rains have started here";
		String str1="The rains have started here";
		System.out.println(str.length()); //length of string
		System.out.println(str.charAt(5));// char value at specfic index
		System.out.println(str.indexOf('s'));
		System.out.println(str.indexOf('s', 9));//start counting from 9th location
		System.out.println(str.indexOf('s',str.indexOf('s')+1));//second occurence of S
		System.out.println(str.indexOf('s',16));
	    System.out.println(str.indexOf('s', str.indexOf('s',str.indexOf('s')+1)+1));
	    System.out.println(str.indexOf("have"));//check for string presence
	    System.out.println(str.indexOf("hello"));//String is not present return -1
	   
	    // String Comparsion
	    	    
	    System.out.println(str.equals(str1));
	    //ignorecase
	    
	    System.out.println(str.equalsIgnoreCase(str1));
	    
	    //substring 
	    System.out.println(str.substring(0, 9));
	    
	    
	    
	    
	    //trim()--->it will remove before space and after only 
	    String s= "  Hello World ";
	    System.out.println(s);
	    System.out.println(s.trim());
	    
	    
	    
	    
	    //replace()---->if u wnat to remove the middle space 
	    System.out.println(s.replace(" ",""));
	    String date="01-01-2017";
	    System.out.println(date.replace("-", "/"));
	    
	    
	    
	    //split
	    
	   String test="Hello_World_Test_Selenium";
	   test.split("_");
	   String testval[]=test.split("_");
	   for(int i=0;i<testval.length;i++)
	   {
		   System.out.println(testval[i]);
	   }
	   
	   //String.reverse is not possibile becoz strings are immutable
	   //compareto is basis of unicode value 
	   
	   //concate
	   String s2="care";
	   System.out.println(s2.concat("s"));
	   
	  /////Imp question
	   
	   String x="Hello";
	   String y="World";
	   int a=100;
	   int b=200;
	   System.out.println(x+y);
	   System.out.println(a+b);
	   System.out.println(x+y+a+b);//left to right 
	   System.out.println(a+b+x+y);
	   System.out.println(x+y+(a+b));
	   
	   
	   
			   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	    
	    
	    
	    
		
		
		

	}

}
