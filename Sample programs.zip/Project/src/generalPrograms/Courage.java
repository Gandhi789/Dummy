package generalPrograms;

public class Courage {

	public static void main(String[] args) {
		
		
		Integer[] a={20, 10, 25, 63, 96, 57};
		
		int temp;
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				
				if(a[i]>a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
					
					
				}
				
				
				
				
			}
			
			
		}
		System.out.println(a[0]);
		
		
		
		
		

	}

}
