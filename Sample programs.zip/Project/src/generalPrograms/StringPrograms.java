package generalPrograms;

public class StringPrograms {

	public static void main(String[] args) {
		String str="awer23rrr1tt";
		
		//////////////////                           CharAt method 
		
		char[] ch=new char[str.length()];
		
		 // Copy character by character into array
		for(int i=0;i<str.length();i++)
		{
			ch[i]=str.charAt(i);
		}
		
		
		
		////////////////////////
		
		char[] ch1=str.toCharArray();          ///To toCharArray method
		
		
		for(char k:ch1)
		{
				
			if(Character.isDigit(k))
			{
				
				String s1=""+k;
			System.out.print(s1);
			}
		}
		
		
		

	}

}
