package generalPrograms;

public class NaN {
	
	
	//NaN=========Not a number
	
	//Arthmetic expection will come with most of the Integer only

	public static void main(String[] args) {
		
     // System.out.println(2/0);
      
      System.out.println(2.0/0.0);
      System.out.println(0.0/0.0);
System.out.println(Math.sqrt(-1));

System.out.println(Float.NaN==Float.NaN);

System.out.println(Float.NaN!=Float.NaN);

System.out.println("*********************************************");

// Waht will be the output when you divide a number by zero

//Number=Integer,Double,Float


//System.out.println(9/0);
System.out.println(9.0/0);
System.out.println(12.33f/0);
System.out.println(10/0.0);
System.out.println(19.99d/0);






	}

}
