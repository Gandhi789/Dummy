package generalPrograms;

public class TestNum {

	public static void main(String[] args) {

//Compare two int numbers(Integer Caching)
		
		
		//-128 to 127
		Integer num1=190;
		Integer num2=190;
		
		if(num1==num2)
		{
			System.out.println("both are equal");
		}
		else
		{
			System.out.println("both are not equal");
		}
		
		
		
		

	}

}
