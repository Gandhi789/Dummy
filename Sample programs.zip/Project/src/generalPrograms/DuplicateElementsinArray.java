package generalPrograms;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.HashMap ;



public class DuplicateElementsinArray {

	public static void main(String[] args) {
		
		String names[]={"Java","Javascript","Ruby","C","Python","Java","C"};
		
		
		//1.compare each element :O(n*n)----Worst solution it will take time
		
		for(int i=0;i<names.length;i++)
		{
			for(int j=i+1;j<names.length;j++)
			{
				
				if(names[i].equals(names[j]))
				{
					System.out.println("Duplicate element is :" +names[i]);	
				}
				
				
			}
		}
		
		System.out.println("*****************************************");
		
		// Using HashSet:Hash set is a part of java collection ,it stores unique values,O(n)
		Set<String> st=new HashSet<String>();
		for(String k:names)
		{
			if(st.add(k)==false)
			{
				System.out.println("duplicate element :" +k );
			}
				
		}
		
		
		
		
		// 3.Using HashMap
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		
		for(String k:names)
		{
			
			Integer count=map.get(k);
			if(count==null)
			{
				map.put(k, 1);
			}
			else
			{
				map.put(k, ++count);
			}
			
			
		}
		
		//get the values  from this Hashmap
		Set<String> keys= map.keySet();	
		for(String k:keys)
		{
			
			
			if(map.get(k)>1)
			{
				System.out.println("duplicate count"+ k+" "+ map.get(k));
			}
		}
		
		

	}

	}


