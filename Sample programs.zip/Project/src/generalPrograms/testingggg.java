package generalPrograms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class testingggg {

	public static void main(String[] args) {

		String[] array = {"sunday", "monday", "tuesday", "wednesday", "thursday","friday","saturaday","sunday"};
		int big=0;
		String bigword="";
		 
		for( int i=0;i<array.length;i++)
		{
			if(array[i].length()>big)
			{
				big=array[i].length();
				
				bigword=array[i];
				 
			}
			
		}
		System.out.println(big);
		
		System.out.println(bigword);
		
		String rev="";
		
		for(int j=bigword.length()-1;j>=0;j--)
		{
			rev=rev+bigword.charAt(j);
		}
		System.out.println(rev);

	}

}
