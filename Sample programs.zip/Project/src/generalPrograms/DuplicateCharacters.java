package generalPrograms;
import java.util.Collection;
import java.util.HashMap ;
import java.util.List;
import java.util.Map;
import java.util.Set;
public class DuplicateCharacters {

	public static void main(String[] args) {
		String str="my name is king";
		HashMap<Character, Integer> map = new HashMap<Character, Integer>();
		
		char[] ch=str.toCharArray(); // Converting given string into char array
       
	
		
		
		for(char c:ch)  // Checking each character of charArray
		{
			
			if(map.containsKey(c))
			{
				map.put(c, map.get(c)+1);
			}
			
			else
				map.put(c, 1);
						
		}
		
			System.out.println(map);
			
			//System.out.println(map.entrySet());
		
			
		/*for(Map.Entry entry:map.entrySet())
		{
			System.out.println(entry.getKey()+" "+entry.getValue());
			
			  
		}
		*/
		Set<Character> keys= map.keySet();	
		for(Character k:keys)
		{
			
			
			if(map.get(k)>1)
			{
				System.out.println("duplicate count"+ k+" "+ map.get(k));
			}
		}
		
		

	}

}
