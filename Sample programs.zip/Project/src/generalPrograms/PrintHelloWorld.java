package generalPrograms;

public class PrintHelloWorld {

	public static void main(String[] args) {
		

		
		//Print Hello World with out using semi colon(;)
		
		if(System.out.printf("Hello World")==null)
		{
			
		}
		
		
		// 2 way
		
		if(System.out.append("Hello World")== null)
		{
			
		}
		
		// 3 way
		
		if(System.out.append("Hello World").equals(null))
		{
			
		}

	}

}
