package generalPrograms;

public class SwapIntegerwithoutthirsvarable {

	public static void main(String[] args) {

		
		int x=5;
		int y=10;
		
		//----------------------------with using third variable 
		
		int t;
		
		//t=x;//5
		//x=y;//10
		//y=t;//5
		
		//System.out.println(x);
		//System.out.println(y);
		
		//--------------------------with out using third variable 
		
	//	x=x+y;//15
	//	y=x-y;//5
	//	x=x-y;//10
	//	System.out.println(x);
	//	System.out.println(y);
		
		
		//------------------------using multiplication
		
		x=x*y;//50
		y=x/y;//5
		x=x/y;//10
		
		System.out.println(x);
		System.out.println(y);
		
		
		

	}

}
