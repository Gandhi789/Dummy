package generalPrograms;

public class Generalinfo {

	public static void main(String[] args) {

		
		//collection : group of objects as a single object 
		
		//Collection Framework
		
		//Why Collections is need ? reason below
		
		// In array we can store homegenous(same kind of data only) 
		
		//The array is fixed size ,if we use less remaining will wasted 
		
		// arrays are not implemented any Data structure and not able to use ready made methods like sorting
		
		
		//int a[] =new int[10]; array 
		
		//Object a[]=new Object[5] it can hold hetrogenous data 
		
		
		/*   collections(Interface)
		
		  List(I)=======>ArrayList,LinkedList
		  
		  Set(I)========>HashSet,LinkedHashSet
		  
		  Queue(I)=========>Priorty Queue
		  
		  Map(I)===========>Hashmap,Linkedhashmap,HashTable
		   
	methods are available in collection Interface(List,Set,Queue):
		 
		1.add(Object o)------adding single object
		2.addAll(Collection c)--Group of object addding
		3.remove(Object o)
		4.removeAll(Collection c)---Deleting group of objects
		5.retainAll(Collection c)---Expect this "collection c" rest of the objects will be deleted
		6.clear()
		7.isEmpty()
		8.size()
		9.contains(Object o)
		10.containsAll(collection c)
		11.toArray(collection c)---Collection into Array format return object array 
		 
		 */
		
		/*methods available in List Interface 
		 
		add(index,object o) just compare with add(object) method from collection will add ate the end only
		addAll(index,collection c)
		remove(index)
		get(index)
		set(index,Object o)---replacing existing object with new object 
		 
		 These are abstract methods so we need to implement in ArrayList and Linked list classes
		 
		 */
		
		//Collections (predefined in class in java.util package) utilites :collections.sort(a1)
		//Collections.shuffle(a1)
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
