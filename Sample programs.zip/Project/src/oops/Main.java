package oops;

//Java Program to illustrate Abstract class
//Without any abstract method

//Class 1
//An abstract class without any abstract method

abstract class Base
{
	void fun()
	{
		System.out.println("Function of Base class is called");
	}
}

class derived extends Base
{
	
}

 class Main {

	public static void main(String[] args) {
		derived d =new derived();
		d.fun();

	}

}
