package oops;

public class Overloaddemo {
	
	public void m1()
	{
		System.out.println("No argument M1 method");
	
	}
	public void m1(int i)
	{
		System.out.println("int argument M1 method");
	}
	
	public void m1(double d)
	{
		System.out.println("double argument M1 method");
	}
	
	public void m1(int i,float f)
	{
		System.out.println("checking position Int first and then float ");
	}
	
	public void m1(float f,int i)
	{
		System.out.println("checking position float first  and then int ");
	}
	

	public static void main(String[] args) {
		Overloaddemo o=new Overloaddemo();
		o.m1('A'); //Here it is type casted to int type from chracter 
o.m1(9.9f, 10);
o.m1(8, 10.9f);
	}

}
