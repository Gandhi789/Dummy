package impStrings;


import java.util.HashMap;

public class Anagramusinghashmap {

	public static void main(String[] args) {

String str1="army";
String str2="mary";

char[] ch1=str1.toCharArray();

char[] ch2=str2.toCharArray();

HashMap<Character,Integer> map=new HashMap<Character,Integer>();

for(char c :ch1)
{
	if(map.containsKey(c))
	{
		map.put(c, map.get(c)+1);
	}
	else
	{
		map.put(c, 1);
	}

}

System.out.println(map);


for(char c:ch2)
{
	if(map.containsKey(c))
	{
		map.put(c, map.get(c)-1);
	}
	
	
}
System.out.println(map);

System.out.println(map.values());

		
		
	}

}
