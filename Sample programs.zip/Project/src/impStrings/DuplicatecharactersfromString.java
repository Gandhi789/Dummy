package impStrings;

import java.util.HashSet;
import java.util.Set;

public class DuplicatecharactersfromString {

	public static void main(String[] args) {


		String str="Programming";
		char[] ch=str.toCharArray();
		Set<Character>  st=new HashSet<Character>();
		for(char c:ch)
		{
			
			if(!st.add(c))
			{
				System.out.println(c);
			}
			
			
			
			
		}
		
		
		

	}

}
