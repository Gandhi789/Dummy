package impStrings;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Set;

public class FirstnonrepeatedcharacterfromStringusinghashmap {

	public static void main(String[] args) {

		
		String str="stress";
		
		
		char[] ch=str.toCharArray();
		HashMap<Character,Integer> map=new LinkedHashMap<Character,Integer>();
		
		for(char c:ch)
		{
			
			if(map.containsKey(c))
			{
				map.put(c, map.get(c)+1);
			}
			else
			{
				map.put(c, 1);
			}
		
		}
		
		System.out.println(map);
		
		
		Set<Character> st=map.keySet();
		for(char c:st)
		{
			
			if(map.get(c)==1)
			{
			System.out.println(c);
			break;
			}
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
