package impStrings;

public class FirstnonrepeatedcharacterfromString {

	public static void main(String[] args) {

		
		String str="stress";
		
		
		char[] ch=str.toCharArray();
		
		for(char c:ch)
		{
			
			if(str.indexOf(c)==str.lastIndexOf(c))
			{
				System.out.print(c);
				break;
			}
			
			
		}

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
