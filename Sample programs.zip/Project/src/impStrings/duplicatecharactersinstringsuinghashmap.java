package impStrings;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class duplicatecharactersinstringsuinghashmap {

	public static void main(String[] args) {
	
		String str="Programming";
		
		char[] ch=str.toCharArray();
		
		HashMap<Character,Integer> map=new HashMap<Character,Integer>();
		
		for(char c:ch)
		{
			
			if(map.containsKey(c))
			{
				map.put(c, map.get(c)+1);
			}
			else
			{
				map.put(c, 1);
			}
			
			
		}
		System.out.println(map);
		
	Set<Character> st=map.keySet();
	for(char c:st)
	{
		System.out.println(c + "   "  + map.get(c) );
	}
		
		
		
		
		
		
		
		
	}		

}
