package impStrings;

import java.util.Arrays;

public class Anagram {

	public static void main(String[] args) {

String str1="army";
String str2="mary";

char[] ch1=str1.toCharArray();

char[] ch2=str2.toCharArray();

Arrays.sort(ch1);
Arrays.sort(ch2);

System.out.println(ch1);
		
System.out.println(ch2);

if(ch1.length==ch2.length && Arrays.equals(ch1, ch2))
{
	System.out.println("this is anagram");
}
		
		
		
		
	}

}
