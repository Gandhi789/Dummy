package constructors;


class Geek
{
	int num;
	String name;
	
	Geek()
	{
		System.out.println("I am in default constuctor");
	}
}
public class Tests {

	public static void main(String[] args) {
		
		Geek geek=new Geek();
		System.out.println(geek.name);
		System.out.println(geek.num);

	}

}
