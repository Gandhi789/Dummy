package sdet;


//Natural number >1  first condition 

//which has only 2 factors 1 and itself  second condition 

//19=== 1 and 19 prime number
//28===>1,2,4, Not a prime 

public class PrimeNumberNew {

	public static void main(String[] args) {

		int num=20;
		
		int count=0;
				
		if(num>1)
		{
		
			for(int i=1;i<=num;i++)
			{
				if(num%i==0)
					count++;
			}
			if(count==2)
			{
				System.out.println("it is a prime number ");
			}
			else
			{
				System.out.println("not a prime number ");
			}
			
			
		}
		else
		{
			System.out.println("not prime number");
		}
		

	}

}
