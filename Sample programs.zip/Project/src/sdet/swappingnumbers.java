package sdet;

public class swappingnumbers {

	public static void main(String[] args) {
		
		int a=10, b=20;
		System.out.println("before swapping "+a+" "+b);
		
		//logic 1
		
	/*	int t=a;
		a=b;
		b=t;
		*/
		
		//logic 2 using + & - ,not using third variable 
		
	/*	a=a+b; //10+20=30
		b=a-b;//30-20=10
		a=a-b;// 30-10=20
			
*/		
		
		//Logic 3 --Using multiplication and division operator not using third variable 
		//here a and b values should not be 0
		
		/*a=a*b;   //10*20=200
		b=a/b; //200/20=10
		a=a/b;  //200/10=20
*/		
		
		//logic 4 --single statement
		
		  b=a+b-(a=b);
		
		System.out.println("after swapping "+a+" "+b);
		
		//
		

	}

}
