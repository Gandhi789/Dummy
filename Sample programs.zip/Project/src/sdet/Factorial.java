package sdet;

import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
	
		
		//5!=5*4*3*2*1
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any number");
		int num=sc.nextInt();
		int res=1;
		
		for(int i=num;i>=1;i--)
		{
			res=res*i;
		}
System.out.println(res);
	}

}
