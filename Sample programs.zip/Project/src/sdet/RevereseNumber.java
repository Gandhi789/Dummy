package sdet;

import java.util.Scanner;

public class RevereseNumber {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any number");
		int num=sc.nextInt();    //1234  ---output should be 4321
		
	/*	int rev=0;
		while(num!=0)
		{
			rev=rev*10 +num%10;
			num=num/10;
		}
		System.out.println(rev);
*/
		
		//Using StringBuffer class method
		
		
		/*
		StringBuffer sb=new StringBuffer(String.valueOf(num));
		
		StringBuffer rev=sb.reverse();
		System.out.println(rev);
		*/
		
		//Using String Builder
		
		StringBuilder sb=new StringBuilder();
		sb.append(num);
		StringBuilder rev=sb.reverse();
		System.out.println(rev);
		
	}

}
