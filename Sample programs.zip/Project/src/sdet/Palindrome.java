package sdet;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		//16461
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any number");
		int num=sc.nextInt();
		
		int rev=0;
		int org_num=num;
		 
		while(num!=0)
		{
			rev=rev*10 +num%10;
			num=num/10;

		}
		System.out.println(rev);
		
		if(org_num==rev)
		{
			System.out.println("palindrome");
		}
		else
			System.out.println("not palindrome");

		
		
	}

}
